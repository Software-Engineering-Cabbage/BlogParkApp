package com.example.my_test6.edu_module.Member;

public class Member {
    private String avater;
    private String name;

    public Member(String avater, String name) {
        this.avater = avater;
        this.name = name;
    }

    public String getAvater() {
        return avater;
    }

    public String getName() {
        return name;
    }
}

