package com.example.my_test6.edu_module;

public class EduClass {
    private String avater;
    private String name;

    public EduClass(String avater, String name) {
        this.avater = avater;
        this.name = name;
    }

    public String getAvater() {
        return avater;
    }

    public String getName() {
        return name;
    }
}
