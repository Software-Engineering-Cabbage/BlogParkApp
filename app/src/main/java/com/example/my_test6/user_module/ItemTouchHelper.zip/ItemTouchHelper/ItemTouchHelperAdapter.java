package com.example.my_test6.user_module.ItemTouchHelper;

public interface ItemTouchHelperAdapter {
    public void onItemDelete(int position);
    public void onItemRefresh(int position);
}
